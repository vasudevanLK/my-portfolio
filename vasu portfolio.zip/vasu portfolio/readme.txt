
Copyright information for the template can't be altered/removed unless you purchase a license.

Removing copyright information without the license will result in suspension of your hosting and/or domain name(s).
